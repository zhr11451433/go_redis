package db

import "time"

func (r *Redis) Set(key, value string) {
	r.GetSet(key, value)
}

// GetSet 有这个 Key：更新旧值。
// 没有这个 Key：创建新值
func (r *Redis) GetSet(key, value string) (old string, existed bool) {
	for i := range r.Key {
		entry := &r.Key[i]
		if entry.KeyName != key {
			continue
		}
		if entry.KeyTime <= time.Now().Unix() {
			break
		}
		old := entry.KeyValue
		entry.KeyValue = value
		entry.KeyTime = 0 // 假设 0 表示永不过期
		return old, true
	}

	r.Key = append(r.Key, RedisKey{
		KeyName:  key,
		KeyValue: value,
		KeyType:  "string",
	})
	return "", false
}
