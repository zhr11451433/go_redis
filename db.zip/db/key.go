package db

import (
	"errors"
	"time"
)

func (r *Redis) Del(key string) error {
	for i := range r.Key {
		if r.Key[i].KeyName != key {
			continue
		}
		r.Key = append(r.Key[:i], r.Key[i+1:]...)
		return nil
	}
	return errors.New("key not found")
}

func (r *Redis) Exists(key string) bool {
	_, ok := r.Find(key)
	return ok
}

func (r *Redis) Expire(key string, duration time.Duration) error {
	redisKey, ok := r.Find(key)
	if !ok {
		return errors.New("key not found")
	}
	if duration <= 0 {
		//不过期
		redisKey.KeyTime = 0
		return nil
	}
	redisKey.KeyTime = time.Now().Add(duration).Unix()
	return nil
}

func (r *Redis) Find(key string) (*RedisKey, bool) {
	for i := range r.Key {
		if r.Key[i].KeyName == key && (r.Key[i].KeyTime == 0 || r.Key[i].KeyTime > time.Now().Unix()) {
			return &r.Key[i], true
		}
	}
	return nil, false
}

func (r *Redis) Persist(key string) error {
	redisKey, ok := r.Find(key)
	if !ok {
		return errors.New("key not found")
	}
	redisKey.KeyTime = 0
	return nil
}
