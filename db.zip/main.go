package main

import (
	"bufio"
	"fmt"
	"go_redis/db"
	"log"
	"os"
	"strconv"
	"strings"
	"time"
)

const dataPath = "./redis.json"

func main() {
	redis, err := db.Load(dataPath)
	if err != nil {
		log.Fatalf("Load redis failed: %s", err.Error())
	}
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		line := scanner.Text()
		//strings.Fields() 会按照连续空白字符拆分字符串
		args := strings.Fields(line)
		if len(args) == 0 {
			continue
		}
		command := strings.ToUpper(args[0])
		switch command {
		case "SET", "GETSET":
			if len(args) != 3 {
				fmt.Printf("用法 %s key value\n", command)
				continue
			}

			reply := "OK"
			if command == "SET" {
				redis.Set(args[1], args[2])
			} else {
				old, existed := redis.GetSet(args[1], args[2])
				reply = "(nil)"
				if existed {
					reply = fmt.Sprintf("%q", old)
				}
			}

			if err := db.Save(dataPath, redis); err != nil {
				log.Fatalf("保存失败: %v", err)
			}
			fmt.Println(reply)
		case "FLUSHDB":
			if len(args) != 1 {
				fmt.Printf("用法 %s错误\n", command)
				continue
			}
			if err := db.FlushDB(dataPath, redis); err != nil {
				log.Printf("FlushDB failed: %s\n", err.Error())
			} else {
				fmt.Printf("FlushDB OK\n")
			}
		case "DEL":
			if len(args) != 2 {
				fmt.Printf("用法 %s错误\n", command)
				continue
			}
			if err := redis.Del(args[1]); err != nil {
				log.Println("key 不存在")
			} else {
				if err := db.Save(dataPath, redis); err != nil {
					log.Fatalf("保存失败: %v", err)
				}
				fmt.Printf("Del OK\n")
			}
		case "EXISTS":
			if len(args) != 2 {
				fmt.Printf("用法 %s错误\n", command)
				continue
			}
			ok := redis.Exists(args[1])
			if ok {
				fmt.Println(1)
			} else {
				fmt.Println(0)
			}
		case "EXPIRE":
			if len(args) != 3 {
				fmt.Printf("用法 %s错误\n", command)
				continue
			}
			key := args[1]
			seconds, err := strconv.Atoi(args[2])
			if err != nil {
				log.Println("时间格式错误")
			}
			if err := redis.Expire(key, time.Duration(seconds)*time.Second); err != nil {
				log.Println("过期时间设置失败1")
			}
			if err := db.Save(dataPath, redis); err != nil {
				log.Println("过期时间设置失败2")
			}
			fmt.Println("过期时间设置成功")
		case "PERSIST":
			if len(args) != 2 {
				fmt.Printf("用法 %s错误\n", command)
				continue
			}
			if err := redis.Persist(args[1]); err != nil {
				log.Println("移除过期时间失败1")
			}
			if err := db.Save(dataPath, redis); err != nil {
				log.Println("移除过期时间失败2")
			}
			fmt.Println("移除过期时间成功")
		default:
			fmt.Printf("未实现的命令 %s\n", command)
		}
	}
	if err := scanner.Err(); err != nil {
		_, _ = fmt.Fprintln(os.Stderr, "读取输入失败:", err)
	}
}
